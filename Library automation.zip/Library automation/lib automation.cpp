#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

// these are the constant values for the files names and the limited library staff
// by defing theme at first it is no need to write the file name every time while writing or scaning
#define MAX_BOOKS 100
#define MAX_USERS 100
#define MAX_BORROWINGS 100
#define FILE_BOOKS "library_books.txt"
#define FILE_USERS "library_users.txt"
#define FILE_BORROWINGS "library_borrowings.txt"


// implemenation of structs 
struct Book {
    int number;
    char title[50];
    char author[50];
    int pages;
};
struct User {
    int number;
    char firstName[50];
    char lastName[50];
    char birthDate[15];
};
struct Borrowing {
    int userNumber;
    int bookNumber;
    char startDate[15];
    char endDate[15];
};


// scope of hte display menu
void displayMenu(struct Book books[], int *bookCount, struct User users[], int *userCount, struct Borrowing borrowings[], int *borrowingCount);

// Book function operations
void addBook(struct Book books[], int *bookCount);
void listBooks(struct Book books[], int bookCount);
void updateBook(struct Book books[], int bookCount);
void deleteBook(struct Book books[], int *bookCount, struct Borrowing borrowings[], int borrowingCount);
void searchBook(struct Book books[], int bookCount, const char keyword[]) ;

// User functions Operation
void addUser(struct User users[], int *userCount);
void listUsers(struct User users[], int userCount);
void updateUser(struct User users[], int userCount);
void deleteUser(struct User users[], int *userCount, struct Borrowing borrowings[], int borrowingCount);
void searchUsers(struct User users[], int userCount, const char keyword[]);

// Borrowed function operations
void borrowBook(struct Book books[], int bookCount, struct User users[], int userCount, struct Borrowing borrowings[], int *borrowingCount);
void returnBook(struct Borrowing borrowings[], int *borrowingCount);
void listBorrowings(struct Borrowing borrowings[], int borrowingCount, struct User users[], int userCount, struct Book books[], int bookCount);

// these funcions save the info to the file and scan the saved info from file to the terminal window
void saveBooksToFile(struct Book books[], int bookCount);
void loadBooksFromFile(struct Book books[], int *bookCount);
void saveUsersToFile(struct User users[], int userCount);
void loadUsersFromFile(struct User users[], int *userCount);
void saveBorrowingsToFile(struct Borrowing borrowings[], int borrowingCount);
void loadBorrowingsFromFile(struct Borrowing borrowings[], int *borrowingCount);
void addDaysToDate(char startDate[], char endDate[], int days);



// main funciont 
int main() {
printf("---/\\/\\/\\/\\ Hello, Welcome to the library ---/\\/\\/\\/\\---\n");
    struct Book books[MAX_BOOKS];
    int bookCount = 0;
    loadBooksFromFile(books, &bookCount);

    struct User users[MAX_USERS];
    int userCount = 0;
    loadUsersFromFile(users, &userCount);

    struct Borrowing borrowings[MAX_BORROWINGS];
    int borrowingCount = 0;
    loadBorrowingsFromFile(borrowings, &borrowingCount);

    displayMenu(books, &bookCount, users, &userCount, borrowings, &borrowingCount);

    return 0;
}



// display function 
void displayMenu(struct Book books[], int *bookCount, struct User users[], int *userCount, struct Borrowing borrowings[], int *borrowingCount) {
    int choice;

  do {
    	 step1:
    	 printf("\n<<<---------------------------||------------------------------>>>\n");
    	  printf("    <<<<                  Main Menu               >>>>\n");
    	 printf("<<<---------------------------||------------------------------>>>\n\n");

        printf("1. Book Operations\n");
        printf("2. User Operations\n");
        printf("3. Borrowing Operations\n");
        printf("0. Exit\n");
        printf("Enter your choice: \n");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                // Book Operations

                printf("Book Operations Menu:\n");
                printf("1. Add Book\n");
                printf("2. List Books\n");
                printf("3. Update Book\n");
                printf("4. Delete Book\n");
                printf("5. Serch Book\n");
                printf("0. Main Menu\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                    case 1:
                        addBook(books, bookCount);
                        break;
                    case 2:
                        listBooks(books, *bookCount);
                        break;
                    case 3:
                        updateBook(books, *bookCount);
                        break;
                    case 4:
                        deleteBook(books, bookCount, borrowings, *borrowingCount);
                        break;
                    case 5:
                        char keyword[50];
                        printf("Enter the keyword to search Book: ");
                        scanf("%s", keyword);
                        searchBook(books, *bookCount, keyword);
                        break;
                    case 0:
                        printf("Returning to the main menu...\n");
                        goto step1;
                        break;
                    default:
                        printf("Invalid option. Please try again.\n");
                }
                break;

            case 2:
                // User Operations

                printf("User Operations Menu:\n");
                printf("1. Add User\n");
                printf("2. List Users\n");
                printf("3. Update User\n");
                printf("4. Delete User\n");
                printf("5. Search Users\n");
                printf("0. Main Menu\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                    case 1:
                        addUser(users, userCount);
                        break;
                    case 2:
                        listUsers(users, *userCount);
                        break;
                    case 3:
                        updateUser(users, *userCount);
                        break;
                    case 4:
                        deleteUser(users, userCount, borrowings, *borrowingCount);
                        break;
                    case 5:
                        char keyword[50];
                        printf("Enter the keyword to search users: ");
                        scanf("%s", keyword);
                        searchUsers(users, *userCount, keyword);
                        break;
                    case 0:
                        printf("Returning to the main menu...\n");
                        goto step1;
                        break;
                    default:
                        printf("Invalid option. Please try again.\n");
                }
                break;

            case 3:
                // Borrowing Operations
                printf("Borrowing Operations Menu:\n");
                printf("1. Borrow a Book\n");
                printf("2. Return a Book\n");
                printf("3. List Borrowings\n");
                printf("0. Main Menu\n");
                printf("Enter your choice: ");
                scanf("%d", &choice);

                switch (choice) {
                    case 1:
                        borrowBook(books, *bookCount, users, *userCount, borrowings, borrowingCount);
                        break;
                    case 2:
                        returnBook(borrowings, borrowingCount);
                        break;
                    case 3:
                        listBorrowings(borrowings, *borrowingCount, users, *userCount, books, *bookCount);
                        break;
                    case 0:
                        printf("Returning to the main menu...\n");
                        goto step1;
                        break;
                    default:
                        printf("Invalid option. Please try again.\n");
                }
                break;

            case 0:
                printf("Exiting the program...\n");
                break;

            default:
                printf("Invalid option. Please try again.\n");
        }

    } while (choice != 0);
}




// book functions
void addBook(struct Book books[], int *bookCount) {
if (*bookCount == MAX_BOOKS) {
printf("Error: Maximum number of books reached.\n");
return;
}
printf("Enter book title: ");
scanf(" %49[^\n]", books[*bookCount].title);

printf("Enter author name: ");
scanf(" %49[^\n]", books[*bookCount].author);

printf("Enter number of pages: ");
scanf("%d", &books[*bookCount].pages);

books[*bookCount].number = (*bookCount) + 1;
 (*bookCount)++;

saveBooksToFile(books, *bookCount);

printf("Book added successfully!\n");
}

void listBooks(struct Book books[], int bookCount) {
  //loadBooksFromFile( books,  &bookCount);

if (bookCount == 0) {
printf("\n No books available.\n");
return;
}


printf("\nList of Books:\n");
printf("---------------------------------------------------------\n");
printf("| %-4s | %-30s | %-20s | %-5s |\n", "ID", "Title", "Author", "Pages");
printf("---------------------------------------------------------\n");
for (int i = 0; i < bookCount; i++) {
    printf("| %-4d | %-30s | %-20s | %-5d |\n", books[i].number, books[i].title, books[i].author, books[i].pages);
}

printf("---------------------------------------------------------\n");

}

void updateBook(struct Book books[], int bookCount) {
if (bookCount == 0) {
printf("No books available to update.\n");
return;
}
int bookNumber;
printf("Enter the book number to update: ");
scanf("%d", &bookNumber);

int index = -1;
for (int i = 0; i < bookCount; i++) {
    if (books[i].number == bookNumber) {
        index = i;
        break;
    }
}

if (index == -1) {
    printf("Book not found.\n");
    return;
}

printf("Enter updated title: ");
scanf(" %49[^\n]", books[index].title);

printf("Enter updated author: ");
scanf(" %49[^\n]", books[index].author);

printf("Enter updated number of pages: ");
scanf("%d", &books[index].pages);

saveBooksToFile(books, bookCount);

printf("Book updated successfully!\n");
}

void deleteBook(struct Book books[], int *bookCount, struct Borrowing borrowings[], int borrowingCount) {
    if (*bookCount == 0) {
        printf("No books available to delete.\n");
        return;
    }

    int bookNumber;
    printf("Enter the book number to delete: ");
    scanf("%d", &bookNumber);

    int index = -1;
    for (int i = 0; i < *bookCount; i++) {
        if (books[i].number == bookNumber) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("Book not found.\n");
        return;
    }

    // Check if the book is currently borrowed
    for (int i = 0; i < borrowingCount; i++) {
        if (borrowings[i].bookNumber == bookNumber) {
            printf("Cannot delete the book. It is currently borrowed by someone.\n");
            return;
        }
    }

    for (int i = index; i < *bookCount - 1; i++) {
        books[i] = books[i + 1];
    }

    (*bookCount)--;

    saveBooksToFile(books, *bookCount);

    printf("Book deleted successfully!\n");
}

void searchBook(struct Book books[], int bookCount, const char keyword[]) {
    int found = 0; // Flag to track if any match is found

    for (int i = 0; i < bookCount; ++i) {
        if (strcmp(keyword, books[i].title) == 0 || strcmp(keyword, books[i].title) < 0 )  {
            found = 1; // Set the flag to true
            break; // No need to continue checking once a match is found
        }
    }

    if (!found) {
        printf("\nThe following Book is not found!!\n");
        return;
    }

    printf("\nSearch Results:\n");
    printf("---------------------------------------------------------\n");
    printf("| %-4s | %-30s | %-20s | %-5s |\n", "ID", "Title", "Author", "Pages");
    printf("---------------------------------------------------------\n");

    for (int i = 0; i < bookCount; ++i) {
        if (strstr(books[i].title, keyword) != NULL || strstr(books[i].author, keyword) != NULL) {
            printf("| %-4d | %-30s | %-20s | %-5d |\n", books[i].number, books[i].title, books[i].author, books[i].pages);
        }
    }

    printf("---------------------------------------------------------\n");
}

void saveBooksToFile(struct Book books[], int bookCount) {
FILE *file = fopen(FILE_BOOKS, "w");
if (file == NULL) {
printf("Error opening file for writing.\n");
exit(EXIT_FAILURE);
}




for (int i = 0; i < bookCount; i++) {
   fprintf(file, "%d;%s;%s;%d\n", books[i].number, books[i].title, books[i].author, books[i].pages);

}

fclose(file);
}

void loadBooksFromFile(struct Book books[], int *bookCount) {
 FILE *file = fopen(FILE_BOOKS, "r");
if (file == NULL) {
perror("Error opening file for reading");
return;
}
while (fscanf(file, "%d;%49[^;];%49[^;];%d\n", &books[*bookCount].number,
              books[*bookCount].title, books[*bookCount].author, &books[*bookCount].pages) == 4) {
    (*bookCount)++;
}

fclose(file);
}




// user's functions
void addUser(struct User users[], int *userCount) {
if (*userCount == MAX_USERS) {
printf("Error: Maximum number of users reached.\n");
return;
}
printf("Enter user first name: ");
scanf(" %49[^\n]", users[*userCount].firstName);

printf("Enter user last name: ");
scanf(" %49[^\n]", users[*userCount].lastName);

printf("Enter user birth date: ");
scanf(" %14[^\n]", users[*userCount].birthDate);

users[*userCount].number = (*userCount) + 1;
(*userCount)++;

saveUsersToFile(users, *userCount);

printf("User added successfully!\n");
}

void listUsers(struct User users[], int userCount) {

  //  loadUsersFromFile(users, &userCount);

if (userCount == 0) {
printf("\nNo users available.\n\n");
return;
}

    printf("\nList of Users:\n");
printf("---------------------------------------------------------\n");
printf("| %-4s | %-20s | %-20s | %-15s |\n", "ID", "First Name", "Last Name", "Birthdate");
printf("---------------------------------------------------------\n");

for (int i = 0; i < userCount; ++i) {
    printf("| %-4d | %-20s | %-20s | %-15s |\n", users[i].number, users[i].firstName, users[i].lastName, users[i].birthDate);
}

printf("---------------------------------------------------------\n");



}

void updateUser(struct User users[], int userCount) {
if (userCount == 0) {
printf("No users available to update.\n");
return;
}
int userNumber;
printf("Enter the user number to update: ");
scanf("%d", &userNumber);

int index = -1;
for (int i = 0; i < userCount; i++) {
    if (users[i].number == userNumber) {
        index = i;
        break;
    }
}

if (index == -1) {
    printf("User not found.\n");
    return;
}

printf("Enter updated first name: ");
scanf(" %49[^\n]", users[index].firstName);

printf("Enter updated last name: ");
scanf(" %49[^\n]", users[index].lastName);

printf("Enter updated birth date: ");
scanf(" %14[^\n]", users[index].birthDate);

saveUsersToFile(users, userCount);

printf("User updated successfully!\n");
}

void deleteUser(struct User users[], int *userCount, struct Borrowing borrowings[], int borrowingCount) {
    if (*userCount == 0) {
        printf("No users available to delete.\n");
        return;
    }

    int userNumber;
    printf("Enter the user number to delete: ");
    scanf("%d", &userNumber);

    int index = -1;
    for (int i = 0; i < *userCount; i++) {
        if (users[i].number == userNumber) {
            index = i;
            break;
        }
    }

    if (index == -1) {
        printf("User not found.\n");
        return;
    }

    // Check if the user has borrowed books
    for (int i = 0; i < borrowingCount; i++) {
        if (borrowings[i].userNumber == userNumber) {
            printf("\n User can't be deleted, He/She possess borrowed books!\n");
            return;
        }
    }

    for (int i = index; i < *userCount - 1; i++) {
        users[i] = users[i + 1];
    }

    (*userCount)--;

    saveUsersToFile(users, *userCount);

    printf("User deleted");
}

void searchUsers(struct User users[], int userCount, const char keyword[]) {
	// search if the name or last name is exit or not
int found=0;
	
printf("\nSearch Results:\n");
printf("---------------------------------------------------------\n");
printf("| %-4s | %-20s | %-20s | %-15s |\n", "ID", "First Name", "Last Name", "Birthdate");
printf("---------------------------------------------------------\n");
for (int i = 0; i < userCount; ++i) {
    if (strstr(users[i].firstName, keyword) != NULL || strstr(users[i].lastName, keyword) != NULL || strstr(users[i].birthDate, keyword) != NULL) {
        printf("| %-4d | %-20s | %-20s | %-15s |\n", users[i].number, users[i].firstName, users[i].lastName, users[i].birthDate);
        found =1;
    }
}
   if (!found) {
        printf(" User is not found !! \n");
    }

printf("---------------------------------------------------------\n");
}

void saveUsersToFile(struct User users[], int userCount) {
    FILE *file = fopen(FILE_USERS, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < userCount; i++) {
        fprintf(file, "%d;%s;%s;%s\n", users[i].number, users[i].firstName, users[i].lastName, users[i].birthDate);
    }

    fclose(file);
}

void loadUsersFromFile(struct User users[], int *userCount) {
    FILE *file = fopen(FILE_USERS, "r");
    if (file == NULL) {
        perror("Error opening file for reading");
        return;
    }

    while (fscanf(file, "%d;%49[^;];%49[^;];%14[^\n]", &users[*userCount].number,
                  users[*userCount].firstName, users[*userCount].lastName, users[*userCount].birthDate) == 4) {
        (*userCount)++;
    }
     fclose(file);


}




// borrowing functions
void borrowBook(struct Book books[], int bookCount, struct User users[], int userCount, struct Borrowing borrowings[], int *borrowingCount) {
   if (bookCount == 0 || userCount == 0) {
printf("Cannot borrow a book. Ensure there are books and users available.\n");
return;
}

int bookNumber, userNumber;
printf("Enter the book number to borrow: ");
scanf("%d", &bookNumber);

int bookIndex = -1;
for (int i = 0; i < bookCount; i++) {
    if (books[i].number == bookNumber) {
        bookIndex = i;
        break;
    }
}

if (bookIndex == -1) {
    printf("Book not found !!!\n");
    return;
}

printf("Enter the user number to borrow the book: ");
scanf("%d", &userNumber);

int userIndex = -1;
for (int i = 0; i < userCount; i++) {
    if (users[i].number == userNumber) {
        userIndex = i;
        break;
    }
}

if (userIndex == -1) {
    printf("User not found!!!!\n");
    return;
}

// Check if the book is already borrowed
for (int i = 0; i < *borrowingCount; i++) {
    if (borrowings[i].bookNumber == bookNumber) {
        printf("\n ---- Book is already borrowed. Cannot borrow again!!! ------\n");
        return;
    }
}

printf("Enter start date (YYYY-MM-DD): ");
scanf(" %14[^\n]", borrowings[*borrowingCount].startDate);



// Assuming a fixed borrowing period of 14 days
// You can modify this based on your requirements
// or ask the user to input the number of days.
printf("Borrowing period is 14 days.\n");
// Calculate end date (start date + 14 days)
strcpy(borrowings[*borrowingCount].endDate, borrowings[*borrowingCount].startDate);
// You can add a function to calculate the end date based on the borrowing period.

borrowings[*borrowingCount].userNumber = userNumber;
borrowings[*borrowingCount].bookNumber = bookNumber;
(*borrowingCount)++;

saveBorrowingsToFile(borrowings, *borrowingCount);

printf("Book borrowed successfully!\n");
}

void returnBook(struct Borrowing borrowings[], int *borrowingCount) {
if (*borrowingCount == 0) {
printf("No books currently borrowed.\n");
return;
}
int bookNumber;
printf("Enter the book number to return: ");
scanf("%d", &bookNumber);

int index = -1;
for (int i = 0; i < *borrowingCount; i++) {
    if (borrowings[i].bookNumber == bookNumber) {
        index = i;
        break;
    }
}

if (index == -1) {
    printf("Book not currently borrowed.\n");
    return;
}

// You can add additional checks or calculations related to returning a book if needed.

// Remove the book from the list of borrowings
for (int i = index; i < *borrowingCount - 1; i++) {
    borrowings[i] = borrowings[i + 1];
}

(*borrowingCount)--;

saveBorrowingsToFile(borrowings, *borrowingCount);

printf("Book returned successfully!\n");
}

void listBorrowings(struct Borrowing borrowings[], int borrowingCount, struct User users[], int userCount, struct Book books[], int bookCount) {
    if (borrowingCount == 0) {
        printf("No books currently borrowed.\n");
        return;
    }

    printf("\nList of Borrowings:\n");
    printf("-----------------------------------------------------------------------\n");
    printf("| %-4s | %-20s | %-30s | %-15s | %-15s |\n", "ID", "User", "Book Title", "Start Date", "End Date");
    printf("-----------------------------------------------------------------------\n");

    for (int i = 0; i < borrowingCount; ++i) {
        int userIndex = -1;
        int bookIndex = -1;

        // Find the user for the borrowing
        for (int j = 0; j < userCount; ++j) {
            if (users[j].number == borrowings[i].userNumber) {
                userIndex = j;
                break;
            }
        }

        // Find the book for the borrowing
        for (int j = 0; j < bookCount; ++j) {
            if (books[j].number == borrowings[i].bookNumber) {
                bookIndex = j;
                break;
            }
        }

        // Print borrowing details
        printf("| %-4d | %-20s | %-30s | %-15s | %-15s |\n", borrowings[i].bookNumber,
               (userIndex != -1) ? users[userIndex].firstName : "Unknown User",
               (bookIndex != -1) ? books[bookIndex].title : "Unknown Book",
               borrowings[i].startDate, "Not returned yet!");
    }

    printf("-----------------------------------------------------------------------\n");
}

void saveBorrowingsToFile(struct Borrowing borrowings[], int borrowingCount) {
    FILE *file = fopen(FILE_BORROWINGS, "w");
    if (file == NULL) {
        printf("Error opening file for writing.\n");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < borrowingCount; i++) {
        fprintf(file, "%d;%d;%s;%s\n", borrowings[i].userNumber, borrowings[i].bookNumber,
                borrowings[i].startDate, borrowings[i].endDate);
    }

    fclose(file);
}

void loadBorrowingsFromFile(struct Borrowing borrowings[], int *borrowingCount) {
    FILE *file = fopen(FILE_BORROWINGS, "r");
    if (file == NULL) {
        perror("Error opening file for reading");
        return;
    }

    while (fscanf(file, "%d;%d;%14[^;];%14[^\n]", &borrowings[*borrowingCount].userNumber, &borrowings[*borrowingCount].bookNumber,
                  borrowings[*borrowingCount].startDate, borrowings[*borrowingCount].endDate) == 4) {
        (*borrowingCount)++;
    }

    fclose(file);
}



// this is just a sample of a library that I wrote but it can be written more widlly and with verity of tasks, which I am plannig to do
// Thank you my dear teacher












